# Sourcetree Puppet Module for Boxen

Install [SourceTree](http://sourcetreeapp.com) for Mac OS X.

## Usage

```puppet
include sourcetree
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
